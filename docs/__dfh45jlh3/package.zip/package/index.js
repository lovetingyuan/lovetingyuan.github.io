/**
 * Example problem with existing solution and passing test.
 * See problem 0 in the spec file for the assertion
 * @returns {string}
 */
exports.example = () => 'hello world';

exports.stripPrivateProperties = (privateProperties, dataList) => {
  return dataList.map((data) => {
    const keys = Object.keys(data);
    for (const key of keys) {
      if (privateProperties.includes(key)) {
        delete data[key];
      }
    }
    return data;
  });
};
exports.excludeByProperty = (excludedProperty, dataList) => {
  return dataList.filter((data) => !data[excludedProperty]);
};
exports.sumDeep = (objectsList) => {
  return objectsList.map(({ objects }) => {
    const sum = objects.reduce((a, b) => a + b.val, 0);
    return { objects: sum };
  });
};
exports.applyStatusColor = (colorStatusMap, statusList) => {
  const statusColorList = [];
  const statusColorMap = {};
  const colors = Object.keys(colorStatusMap);
  for (const color of colors) {
    for (const status of colorStatusMap[color]) {
      statusColorMap[status] = color;
    }
  }
  for (const { status } of statusList) {
    const color = statusColorMap[status];
    color && statusColorList.push({ status, color });
  }
  return statusColorList;
};
exports.createGreeting = (callback, ...args1) => {
  return function (...args2) {
    return callback.apply(this, [...args1, ...args2]);
  };
};
exports.setDefaults = (defaultValue) => {
  return function (objValue) {
    return {
      ...defaultValue,
      ...objValue,
    };
  };
};
exports.fetchUserByNameAndUsersCompany = (userName, apiServices) => {
  return Promise.all([apiServices.fetchStatus(), apiServices.fetchUsers()])
    .then(([status, users]) => {
      const user = users.find((user) => user.name === userName);
      return Promise.all([
        status,
        user,
        apiServices.fetchCompanyById(user.companyId),
      ]);
    })
    .then(([status, user, company]) => {
      return {
        company,
        status,
        user,
      };
    });
};
